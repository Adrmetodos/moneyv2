// Este arquivo é apenas para garantir que a Vercel valide o projeto corretamente
export default {
  setup: () => {
    return {
      teardown: () => {},
    };
  },
};