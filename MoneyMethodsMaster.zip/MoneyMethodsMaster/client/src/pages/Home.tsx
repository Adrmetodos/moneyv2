import LandingPagePro from "@/components/LandingPagePro";

export default function Home() {
  return <LandingPagePro />;
}
